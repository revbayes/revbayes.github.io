CW1 - high island? 0=no, 1=yes     # use
CW2 - uplift? 0=no 1=yes           # do not use
QW1 - size (km^2)                  # use
QW2 - log-size (km^2)              # do not use
CB1 - old-to-young? 0=no 1=yes     # use
QB1 - distance (km)                # use

